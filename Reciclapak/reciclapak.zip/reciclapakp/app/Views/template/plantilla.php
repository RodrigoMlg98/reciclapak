<?= $this->include('components/header') ?>
<?= $this->include('components/menu')?>
<?= $this->renderSection('content') ?>
<?= $this->include('components/footer') ?>